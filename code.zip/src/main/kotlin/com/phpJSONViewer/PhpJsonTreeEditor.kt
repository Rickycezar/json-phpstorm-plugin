package com.phpJSONViewer

import com.intellij.openapi.fileEditor.FileEditor
import com.intellij.openapi.fileEditor.FileEditorLocation
import com.intellij.openapi.fileEditor.FileEditorState
import com.intellij.openapi.project.Project
import com.intellij.openapi.util.UserDataHolderBase
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.ui.components.JBScrollPane
import com.intellij.ui.treeStructure.Tree
import com.google.gson.JsonParser
import com.google.gson.JsonElement
import java.beans.PropertyChangeListener
import javax.swing.JComponent
import javax.swing.tree.DefaultMutableTreeNode
import javax.swing.tree.DefaultTreeModel

class PhpJsonTreeEditor(private val project: Project, private val file: VirtualFile) : UserDataHolderBase(), FileEditor {
    private val panel: JBScrollPane

    init {
        val content = String(file.contentsToByteArray())
        val regex = Regex("""<\?php\s*/\*(.*?)\*/\s*\?>""", RegexOption.DOT_MATCHES_ALL)
        val jsonString = regex.find(content)?.groupValues?.get(1)?.trim() ?: "{}"

        val rootNode = DefaultMutableTreeNode("JSON Root")
        
        try {
            val jsonElement = JsonParser.parseString(jsonString)
            buildTree(jsonElement, rootNode, "Dados")
        } catch (e: Exception) {
            rootNode.add(DefaultMutableTreeNode("Erro de Sintaxe no JSON: ${e.message}"))
        }

        val tree = Tree(DefaultTreeModel(rootNode))
        panel = JBScrollPane(tree)
    }

    private fun buildTree(element: JsonElement, parentNode: DefaultMutableTreeNode, name: String) {
        when {
            element.isJsonObject -> {
                val node = DefaultMutableTreeNode("$name: {}")
                parentNode.add(node)
                element.asJsonObject.entrySet().forEach { (key, value) ->
                    buildTree(value, node, key)
                }
            }
            element.isJsonArray -> {
                val node = DefaultMutableTreeNode("$name: []")
                parentNode.add(node)
                element.asJsonArray.forEachIndexed { index, value ->
                    buildTree(value, node, "[$index]")
                }
            }
            element.isJsonNull -> {
                parentNode.add(DefaultMutableTreeNode("$name: null"))
            }
            else -> {
                parentNode.add(DefaultMutableTreeNode("$name: ${element.asString}"))
            }
        }
    }

    override fun getComponent(): JComponent = panel
    override fun getPreferredFocusedComponent(): JComponent? = panel
    override fun getName(): String = "JSON Tree"
    override fun getFile(): VirtualFile = file
    override fun setState(state: FileEditorState) {}
    override fun isModified(): Boolean = false
    override fun isValid(): Boolean = true
    override fun addPropertyChangeListener(listener: PropertyChangeListener) {}
    override fun removePropertyChangeListener(listener: PropertyChangeListener) {}
    override fun dispose() {}
    override fun getCurrentLocation(): FileEditorLocation? = null
}